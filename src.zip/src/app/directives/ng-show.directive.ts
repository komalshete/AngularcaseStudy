import { Directive, TemplateRef, ViewContainerRef, Input } from '@angular/core';

@Directive({
  selector: '[ngShow]'
})
export class NgShowDirective {

  constructor(private t:TemplateRef<any>,private vcr:ViewContainerRef) {

    console.log("NgShow directive created....");
  }



  @Input()
  set ngShow(show:boolean){
    console.log("Inb setNgShow :"+show);
   if(show)
   this.vcr.createEmbeddedView(this.t);
   else
   this.vcr.clear();
  }


}
