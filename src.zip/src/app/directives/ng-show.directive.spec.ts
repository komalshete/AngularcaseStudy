import { NgShowDirective } from './ng-show.directive';

describe('NgShowDirective', () => {
  it('should create an instance', () => {
    const directive = new NgShowDirective();
    expect(directive).toBeTruthy();
  });
});
