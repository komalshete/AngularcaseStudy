import { Directive, TemplateRef, ViewContainerRef, Input } from '@angular/core';

@Directive({
  selector: '[ngHide]'
})
export class NgHideDirective {

  constructor(private t:TemplateRef<any>,private vcr:ViewContainerRef) {

    console.log("NgHide directive created....");
  }



  @Input()
  set ngHide(show:boolean){
    console.log("Inb setNgHide :"+show);
   if(!show)
   this.vcr.createEmbeddedView(this.t);
   else
   this.vcr.clear();
  }


}
