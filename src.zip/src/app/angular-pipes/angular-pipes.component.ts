import { Component } from '@angular/core';
import { Observable, Subscriber } from 'rxjs';

@Component({
  selector: 'app-angular-pipes',
  templateUrl: './angular-pipes.component.html',
  styleUrls: ['./angular-pipes.component.css']
})
export class AngularPipesComponent  {

  title='Angular  Pipes';

  rows=1;

  searchText='';

  time=new Observable<string>((s:Subscriber<string>)=>{
   setInterval(()=>s.next(new Date().toLocaleString()),1000);
  });


  sortColumn='id';
  reverse=false;


  sort(column:string){
   if(this.sortColumn==column)
    this.reverse=!this.reverse;
    this.sortColumn=column;
  }



  employees=[
    {id:12,name:'ram sharma',salary:45678.2232214,gender:1,age:41,
    city:'Pune',pan:'vvxpc9834d',dob:new Date("July 31,1968")
   },
   {id:42,name:'sachin sharma',salary:322678.22132214,gender:1,age:42,
   city:'Pune',pan:'MAxpc9834d',dob:new Date("July 31,1975")
  },
  {id:22,name:'ameya sharma',salary:33678,gender:1,age:43,
  city:'Nagpur',pan:'PVxpc9834d',dob:new Date("July 31,1973")
 },
 {id:21,name:'priyanka sharma',salary:445678.3112214,gender:2,age:35,
 city:'Solapur',pan:'SVxpc9834d',dob:new Date("July 31,1972")
},
{id:32,name:'ramesh sharma',salary:66678.333332214,gender:3,age:42,
city:'Mumbai',pan:'VBxpc9834d',dob:new Date("July 31,1971")
}
 ];


 




  constructor() {
    console.log("AngularPipesComponent created...");

   }

  ngOnInit() {
    console.log("AngularPipesComponent initialized...");
    
  }
  
  ngOnDestroy() {
    console.log("AngularPipesComponent destroyed...");
    
  }
  
}
