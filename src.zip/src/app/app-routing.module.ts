import { UsersTableComponent } from './users-table/users-table.component';
import { UsersListComponent } from './users-list/users-list.component';
import { PhotosComponent } from './photos/photos.component';
import { AlbumsComponent } from './albums/albums.component';
import { CommentsComponent } from './comments/comments.component';
import { PostsComponent } from './posts/posts.component';
import { UsersComponent } from './users/users.component';
import { FormValidationComponent } from './form-validation/form-validation.component';
import { CustomDirectivesComponent } from './custom-directives/custom-directives.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { EmployeesComponent } from './employees/employees.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TechnologiesComponent } from './technologies/technologies.component';
import { NestedComponentsComponent } from './nested-components/nested-components.component';
import { TodosComponent } from './todos/todos.component';

const routes: Routes = [
  {path:'basics',component:AngularBasicsComponent},
  {path:'technologies',component:TechnologiesComponent},
  {path:'pipes',component:AngularPipesComponent},
  {path:'pipes',component:AngularPipesComponent},
  {path:'employees',component:EmployeesComponent},
  {path:'casestudy',component:CaseStudyComponent,
  children:[
    {path:'users',component:UsersComponent,
     children:[
      {path:'list',component:UsersListComponent},
      {path:'table',component:UsersTableComponent},
    
     ]
  
  
    },
    {path:'users/:userId',component:UsersComponent},
    
    {path:'posts',component:PostsComponent},
    {path:'comments',component:CommentsComponent},
    {path:'albums',component:AlbumsComponent},
    {path:'todos',component:TodosComponent},
    {path:'photos',component:PhotosComponent},
]





   },
  {path:'custom-directives',component:CustomDirectivesComponent},
  {path:'nested-comp',component:NestedComponentsComponent},
  {path:'form-validation',component:FormValidationComponent},
  
  
  {path:'**',redirectTo:'basics'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
