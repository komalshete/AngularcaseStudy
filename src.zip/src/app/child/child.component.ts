import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {


  message='Child Message';

  @Input()
  parentMessage='';

  @Output()
  childChanged=new EventEmitter<string>();


  constructor() { }

  ngOnInit() {
  }


 sendMessageToParent(){
   console.log("In setMEssageToParent :"+this.message);
   this.childChanged.emit(this.message);
 }


}
