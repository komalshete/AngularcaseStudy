import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeesService {
private baseURL="http://localhost:1111/companymysql/users";


 constructor(private http:HttpClient) {
  console.log("EmployeesService created....."); 
  }

  getAllEmployees():Observable<any>{
    return this.http.get(this.baseURL)
  }
  
  getEmployee(id:number):Observable<any>{
    return this.http.get(this.baseURL+"/"+id);
  }

  deleteEmployee(id:number):Observable<any>{
    return this.http.delete(this.baseURL+"/"+id);
  }

  updateEmployee(id:number,employee:any):Observable<any>{
    return this.http.put(this.baseURL+"/"+id,employee);
  }
  
  addEmployee(employee:any):Observable<any>{
    return this.http.post(this.baseURL,employee);
  }
  










}

